# Employee Table Schema

Just a clean SQL table setup for employees.  
It includes the basic structure — no data yet, just the table design.